========================================================
  Hills Lite Pro —— 一键解锁安装包
========================================================

【是的，直接安装就能用】
  在另一台 Windows 上：
    1. 微软商店先装好 Hills Lite（本体）
    2. 解压本包 → 双击 install.bat
    3. 等提示「安装完成」
    4. 直接打开 Hills Lite，无需 bat、无需手动命令

  没有装过 Python 也没关系：安装程序会自动下载便携运行时。
  首次需要联网（约 1~3 分钟）。

【卸载】
  双击 uninstall.bat

【检查状态】
  双击 status.bat

【落盘位置】
  %LOCALAPPDATA%\HillsLiteProUnlock\

【注意】
  · 必须先有商店版 Hills Lite，本包不是完整游戏安装包
  · 应用大版本升级后若失效，需更新本解锁包
  · 杀软可能拦截 Frida，请允许后重装
  · 仅供学习研究

【出问题看日志】
  %LOCALAPPDATA%\HillsLiteProUnlock\installer.log
  %LOCALAPPDATA%\HillsLiteProUnlock\unlock_auto.log
========================================================
