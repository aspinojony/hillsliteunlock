#Requires -Version 5.1
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$InstallDir = Join-Path $env:LOCALAPPDATA "HillsLiteProUnlock"

Write-Host "==== Hills Lite Pro 解锁状态 ====" -ForegroundColor Cyan
Write-Host ("安装目录: {0}  exists={1}" -f $InstallDir, (Test-Path $InstallDir))

$appx = Get-AppxPackage -Name "Mountains.HillsLite" -ErrorAction SilentlyContinue | Select-Object -First 1
if ($appx) {
    Write-Host ("Hills Lite: v{0}" -f $appx.Version)
    Write-Host ("路径: {0}" -f $appx.InstallLocation)
} else {
    Write-Host "Hills Lite: 未安装" -ForegroundColor Red
}

$h = Get-Process HillsLite -ErrorAction SilentlyContinue
Write-Host ("HillsLite 进程: {0}" -f ($(if ($h) { "运行中 PID=" + ($h.Id -join ',') } else { "未运行" })))

$watch = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -and $_.CommandLine -match 'unlock_auto\.py' -and $_.CommandLine -match '--watch' }
Write-Host ("后台监视: {0}" -f ($(if ($watch) { "运行中 PID=" + $watch.ProcessId } else { "未运行" })))

$startup = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Startup\HillsLiteProUnlock.vbs"
Write-Host ("开机 Startup: {0}" -f ($(if (Test-Path $startup) { "有" } else { "无" })))

try {
    $ifeo = (Get-ItemProperty -Path "HKCU:\Software\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\HillsLite.exe" -Name Debugger -ErrorAction Stop).Debugger
    Write-Host ("IFEO: {0}" -f $ifeo)
} catch {
    Write-Host "IFEO: 未设置"
}

$pref = Join-Path $env:LOCALAPPDATA "Packages\Mountains.HillsLite_jja6j3cje9wfy\LocalCache\Roaming\com.mountains\Hills\shared_preferences.json"
if (Test-Path $pref) {
    try {
        $j = Get-Content $pref -Raw -Encoding UTF8 | ConvertFrom-Json
        Write-Host ("prefs isPro: {0}" -f $j.'flutter.isPro')
        Write-Host ("prefs hasValidEntitlement: {0}" -f $j.'flutter.hasValidEntitlement')
    } catch {
        Write-Host "prefs: 无法解析"
    }
} else {
    Write-Host "prefs: 文件不存在(尚未运行过应用)"
}

$log = Join-Path $InstallDir "unlock_auto.log"
if (Test-Path $log) {
    Write-Host ""
    Write-Host "---- 最近日志 ----" -ForegroundColor DarkGray
    Get-Content $log -Tail 15 -ErrorAction SilentlyContinue
}
