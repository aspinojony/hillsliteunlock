#Requires -Version 5.1
$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$InstallDir = Join-Path $env:LOCALAPPDATA "HillsLiteProUnlock"
$PackageRoot = $PSScriptRoot

function Find-Python {
    $p = Join-Path $InstallDir "python.path"
    if (Test-Path $p) {
        $t = (Get-Content $p -Raw).Trim()
        if ($t -and (Test-Path $t)) { return $t }
    }
    foreach ($c in @(
        "$env:LOCALAPPDATA\Programs\Python\Python313\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe"
    )) {
        if (Test-Path $c) { return $c }
    }
    if (Get-Command python -ErrorAction SilentlyContinue) {
        try { return (& python -c "import sys; print(sys.executable)").Trim() } catch {}
    }
    return $null
}

Write-Host "==== 卸载 Hills Lite Pro 无感解锁 ====" -ForegroundColor Yellow

# stop processes
Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -and $_.CommandLine -match 'unlock_auto\.py' } |
    ForEach-Object {
        Write-Host "停止进程 $($_.ProcessId)"
        Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
    }

$python = Find-Python
$script = Join-Path $InstallDir "unlock_auto.py"
if (-not (Test-Path $script)) { $script = Join-Path $PackageRoot "unlock_auto.py" }

if ($python -and (Test-Path $script)) {
    Write-Host "运行 unlock_auto.py --uninstall ..."
    & $python -u $script --uninstall
} else {
    Write-Host "脚本不在，手动清理注册表/启动项..."
    schtasks /Delete /F /TN HillsLiteProUnlock 2>$null | Out-Null
    $vbs = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Startup\HillsLiteProUnlock.vbs"
    if (Test-Path $vbs) { Remove-Item $vbs -Force }
    try {
        Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\HillsLite.exe" -Name Debugger -ErrorAction SilentlyContinue
    } catch {}
}

# optional: remove install dir
Write-Host ""
$ans = Read-Host "是否删除安装目录 $InstallDir ? (Y/N)"
if ($ans -match '^[Yy]') {
    try {
        Remove-Item $InstallDir -Recurse -Force -ErrorAction Stop
        Write-Host "已删除 $InstallDir"
    } catch {
        Write-Host "删除失败(可能被占用): $_" -ForegroundColor Yellow
    }
}

Write-Host "卸载完成。" -ForegroundColor Green
