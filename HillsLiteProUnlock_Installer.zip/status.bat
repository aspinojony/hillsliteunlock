@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Hills Lite Pro 解锁 - 状态检查
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0status.ps1"
echo.
pause
