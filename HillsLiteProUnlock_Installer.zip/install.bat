@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Hills Lite Pro - 一键安装
echo.
echo  ========================================
echo    Hills Lite Pro  一键解锁安装
echo  ========================================
echo.
echo  双击后将自动完成：
echo    1. 准备运行环境（无 Python 会自动下载）
echo    2. 安装解锁组件
echo    3. 设置开机自动生效
echo.
echo  前提：微软商店里已安装 Hills Lite
echo  首次安装需联网（下载运行时约 1~3 分钟）
echo.
echo  正在安装，请稍候...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
set ERR=%ERRORLEVEL%
echo.
if %ERR% neq 0 (
  echo  [失败] 错误码 %ERR%  —— 请把窗口文字截图保存
  echo  日志: %%LOCALAPPDATA%%\HillsLiteProUnlock\installer.log
) else (
  echo  [成功] 现在直接打开 Hills Lite 就是解锁状态
)
echo.
pause
exit /b %ERR%
