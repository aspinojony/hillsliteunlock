"""
Hills Lite — 无感自动解锁 Pro。

安装一次后：直接点开始菜单 / 任务栏里的 Hills Lite 即可，无需 bat。
原理：
  1) 开机静默运行 --watch（兜底 attach）
  2) IFEO 拦截 HillsLite.exe 启动 → spawn 注入（最稳，点图标即生效）

Install (once):
  python unlock_auto.py --install

Uninstall:
  python unlock_auto.py --uninstall
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import time
from pathlib import Path

import frida

HERE = Path(__file__).resolve().parent
TASK_NAME = "HillsLiteProUnlock"
PYTHON = sys.executable
# 隐藏启动用 python.exe + VBS（pythonw 在部分机器上跑 Frida 会静默退出）
LOG_FILE = HERE / "unlock_auto.log"
IFEO_EXE_NAME = "HillsLite.exe"
IFEO_REG_PATHS = (
    # 当前用户优先（通常无需管理员）
    (r"Software\Microsoft\Windows NT\CurrentVersion\Image File Execution Options", True),
    # 机器级兜底
    (r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options", False),
)

_LICENSE = {
    "inCollection": True,
    "isActive": True,
    "isTrial": False,
    "skuStoreId": "9NPROHILLS01",
    "storeId": "9NPROHILLS01",
    "productKind": "Durable",
    "expirationDate": None,
    "inAppOfferToken": None,
    "customDeveloperData": None,
    "extendedJsonData": None,
}


def write_size(n: int) -> bytes:
    if n < 254:
        return bytes([n])
    return bytes([254, n & 0xFF, (n >> 8) & 0xFF])


def write_value(v) -> bytes:
    if v is None:
        return b"\x00"
    if v is True:
        return b"\x01"
    if v is False:
        return b"\x02"
    if isinstance(v, int):
        if -0x80000000 <= v <= 0x7FFFFFFF:
            return b"\x03" + v.to_bytes(4, "little", signed=True)
        return b"\x04" + v.to_bytes(8, "little", signed=True)
    if isinstance(v, str):
        raw = v.encode()
        return b"\x07" + write_size(len(raw)) + raw
    if isinstance(v, list):
        out = b"\x0c" + write_size(len(v))
        for i in v:
            out += write_value(i)
        return out
    if isinstance(v, dict):
        out = b"\x0d" + write_size(len(v))
        for k, val in v.items():
            out += write_value(k)
            out += write_value(val)
        return out
    raise TypeError(type(v))


# Wire: Success(Map[sku]=licenseFields). Empty store reply is 00 0d 00.
FAKE_MAP = b"\x00" + write_value({"9NPROHILLS01": _LICENSE})
TRUE_OK = bytes([0, 1])
NULL_OK = bytes([0, 0])

PACKAGE_FAMILY = "Mountains.HillsLite_jja6j3cje9wfy"
APP_ID = "hillsdesktop"


def _discover_hills() -> tuple[str, str, Path]:
    """Return (exe_path, app_uri, prefs_path). Works across package versions."""
    local = Path(os.environ.get("LOCALAPPDATA", ""))
    prefs = (
        local
        / "Packages"
        / PACKAGE_FAMILY
        / "LocalCache"
        / "Roaming"
        / "com.mountains"
        / "Hills"
        / "shared_preferences.json"
    )
    app_uri = f"shell:AppsFolder\\{PACKAGE_FAMILY}!{APP_ID}"
    exe = ""
    # 1) installed package folder under WindowsApps
    try:
        root = Path(r"C:\Program Files\WindowsApps")
        if root.is_dir():
            cands = sorted(
                root.glob("Mountains.HillsLite_*_x64__jja6j3cje9wfy"),
                key=lambda p: p.name,
                reverse=True,
            )
            for d in cands:
                hit = d / "HillsLite.exe"
                if hit.is_file():
                    exe = str(hit)
                    break
    except Exception:
        pass
    # 2) PowerShell Get-AppxPackage fallback
    if not exe:
        try:
            r = subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    "(Get-AppxPackage Mountains.HillsLite).InstallLocation",
                ],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, "CREATE_NO_WINDOW") else 0,
            )
            loc = (r.stdout or "").strip().splitlines()
            if loc:
                hit = Path(loc[-1].strip()) / "HillsLite.exe"
                if hit.is_file():
                    exe = str(hit)
        except Exception:
            pass
    if not exe:
        exe = r"C:\Program Files\WindowsApps\Mountains.HillsLite_1.3.1.0_x64__jja6j3cje9wfy\HillsLite.exe"
    return exe, app_uri, prefs


EXE, APP_URI, PREFS_PATH = _discover_hills()

# Safer hooks: only rewrite when method name arms expect window.
# (Old sticky rewrite of every empty map crashed other Flutter plugins.)
JS = r"""
'use strict';
const FAKE_MAP = [__FAKE_MAP__];
const TRUE_OK = [0, 1];
const NULL_OK = [0, 0];
function log(m){ send({t:'log', m:''+m}); }
const kept=[];
function alloc(a){ const b=Memory.alloc(a.length); b.writeByteArray(a); kept.push(b); return b; }

let expect='', until=0, nInj=0, bootUntil=0;

function readStdString(p){
  try{
    const size=Number(p.add(16).readU64());
    if(size>0&&size<100){
      const cap=Number(p.add(24).readU64());
      if(cap>15) return p.readPointer().readUtf8String(size);
      return p.readUtf8String(size);
    }
  }catch(e){}
  return null;
}

function arm(kind, why){
  expect=kind;
  until=Date.now()+45000;
  log('expect '+kind+' ('+why+')');
}

function install(){
  const iap=Process.getModuleByName('windows_iap_plugin.dll');
  log('iap@'+iap.base);

  Interceptor.attach(iap.base.add(0x89B0),{onLeave(r){r.replace(ptr(1));}});
  Interceptor.attach(iap.base.add(0x89E0),{onLeave(r){r.replace(ptr(0));}});

  Interceptor.attach(iap.base.add(0xC080),{
    onEnter(args){
      const s=readStdString(args[1])||readStdString(args[0]);
      if(!s) return;
      if(s==='getAddonLicenses') arm('licenses','name');
      else if(s==='checkPurchase') arm('purchase','name');
      else if(s==='getCustomerCollectionsId') arm('collections','name');
      else if(s==='getProducts') log('iap-method '+s);
    }
  });
  Interceptor.attach(iap.base.add(0xD0D0),{onEnter(){ arm('licenses','coro'); }});

  // IAP-only SendResponse site (0x14C14) — safe to catch empty license maps here only
  Interceptor.attach(iap.base.add(0x14C14),{
    onEnter(args){
      try{
        const ctx=this.context;
        const data=ctx.r8, size=Number(ctx.r9);
        let hs='';
        if(size>0&&size<0x10000&&data&&!ptr(data).isNull()){
          const n=Math.min(size,24);
          const head=new Uint8Array(ptr(data).readByteArray(n));
          for(let i=0;i<head.length;i++) hs+=('0'+head[i].toString(16)).slice(-2);
        }
        // 优先用方法名 expect；attach 稍晚则 boot 窗口内拦截空 Map(Success{})
        let kind='';
        if(expect && Date.now()<=until) kind=expect;
        else if(Date.now()<bootUntil && size===3 && hs.indexOf('000d00')===0) kind='licenses';
        else return;

        log('IAP-REPLY kind='+kind+' size='+size+' head='+hs);
        let use=null, tag='';
        if(kind==='purchase'){ use=TRUE_OK; tag='purchase'; }
        else if(kind==='licenses'){ use=FAKE_MAP; tag='licenses-map'; }
        else if(kind==='collections'){ use=NULL_OK; tag='collections-null'; }
        else return;
        const buf=alloc(use);
        ctx.r8=buf; ctx.r9=ptr(use.length);
        nInj++; log('INJECT #'+nInj+' '+tag);
        expect='';
      }catch(e){ log('err '+e); }
    }
  });

  // Soft DNS block for license revoke server (optional; failures are non-fatal)
  try{
    let gai=null;
    try{ gai=Process.getModuleByName('ws2_32.dll').findExportByName('getaddrinfo'); }catch(e){}
    if(!gai){ try{ gai=Module.findExportByName('ws2_32.dll','getaddrinfo'); }catch(e){} }
    if(gai){
      Interceptor.attach(gai,{
        onEnter(args){ try{ this.host=args[0].readUtf8String(); }catch(e){ this.host=null; } },
        onLeave(retval){
          if(this.host && this.host.indexOf('hills.im')!==-1){
            log('DNS-BLOCK '+this.host);
            retval.replace(11001);
          }
        }
      });
      log('DNS block ON');
    }
  }catch(e){ log('DNS fail '+e); }

  // Pre-arm + boot 窗口：attach 稍晚也能截到空 license Map
  arm('licenses','boot');
  bootUntil = Date.now() + 20000;
  log('HOOKS READY');
}

function tryInstall(){
  try{
    Process.getModuleByName('windows_iap_plugin.dll');
    install();
    return true;
  }catch(e){ return false; }
}

if(!tryInstall()){
  log('wait iap dll...');
  const t=setInterval(function(){
    if(tryInstall()) clearInterval(t);
  }, 50);
}
""".replace("__FAKE_MAP__", ", ".join(str(b) for b in FAKE_MAP))

LOG_FILE = HERE / "unlock_auto.log"


def seed_prefs() -> None:
    """Write offline Pro entitlement signals so UI can show Pro even before IAP poll."""
    import json
    from datetime import datetime, timezone

    if not PREFS_PATH.parent.is_dir():
        log_line(f"prefs dir missing: {PREFS_PATH.parent}")
        return
    now_ms = int(time.time() * 1000)
    license_obj = {
        "skuStoreId": "9NPROHILLS01",
        "inCollection": True,
        "isActive": True,
        "isTrial": False,
        "isTestProLicense": False,
        "expirationDate": None,
        "storeId": "9NPROHILLS01",
        "productKind": "Durable",
        "cachedAt": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
        "inAppOfferToken": None,
    }
    data: dict = {}
    if PREFS_PATH.exists():
        try:
            data = json.loads(PREFS_PATH.read_text(encoding="utf-8"))
        except Exception as e:
            log_line(f"prefs read fail: {e}")
            data = {}
    # backup once
    bak = PREFS_PATH.with_suffix(".json.bak_unlock")
    if PREFS_PATH.exists() and not bak.exists():
        try:
            bak.write_text(PREFS_PATH.read_text(encoding="utf-8"), encoding="utf-8")
        except Exception:
            pass
    data["flutter.isPro"] = True
    data["flutter.hasValidEntitlement"] = True
    data["flutter.microsoftStoreIdKey"] = data.get("flutter.microsoftStoreIdKey") or "local-pro-store-id"
    data["flutter.lastEntitlementConfirmedAt"] = now_ms
    data["flutter.lastEntitlementConfirmedAtMs"] = now_ms
    data["flutter.addonLicenses"] = json.dumps([license_obj], separators=(",", ":"))
    try:
        PREFS_PATH.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        log_line("seeded prefs: isPro=True sku=9NPROHILLS01")
    except Exception as e:
        log_line(f"prefs write fail: {e}")


def log_line(msg: str) -> None:
    line = time.strftime("%Y-%m-%d %H:%M:%S ") + msg
    print(line, flush=True)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def find_hills_pids(device) -> list[int]:
    return [p.pid for p in device.enumerate_processes() if p.name == "HillsLite.exe"]


def _process_still_alive(pid: int) -> bool:
    try:
        import ctypes

        SYNCHRONIZE = 0x00100000
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        handle = kernel32.OpenProcess(SYNCHRONIZE, False, pid)
        if not handle:
            return False
        kernel32.CloseHandle(handle)
        return True
    except Exception:
        return pid in find_hills_pids(frida.get_local_device())


def _wait_process_stable(pid: int, settle_s: float = 2.5) -> bool:
    """Wait for process to stay alive so we don't inject into a half-started/crash-loop instance."""
    deadline = time.time() + settle_s
    while time.time() < deadline:
        if not _process_still_alive(pid):
            return False
        time.sleep(0.2)
    return _process_still_alive(pid)


def _hold_session(session, pid: int, detached: dict) -> str:
    """Hold Frida session until process ends. Returns ok|crash."""
    t0 = time.time()
    while not detached["v"]:
        time.sleep(1.5)
        if not _process_still_alive(pid):
            log_line(f"process {pid} exited")
            try:
                session.detach()
            except Exception:
                pass
            break
    lived = time.time() - t0
    if lived < 8 and not _process_still_alive(pid):
        log_line(f"possible frida crash on {pid} (lived {lived:.1f}s); cooling down")
        return "crash"
    return "ok"


def _load_hooks(session, pid: int, detached: dict) -> bool:
    def on_msg(message, data):
        if message["type"] == "send":
            p = message.get("payload")
            if isinstance(p, dict) and p.get("t") == "log":
                log_line(f"[{pid}] {p['m']}")
        elif message["type"] == "error":
            log_line(f"[{pid}] frida-error {message.get('description', message)}")

    try:
        script = session.create_script(JS)
        script.on("message", on_msg)
        script.load()
        log_line(f"hooks on {pid}")
        return True
    except Exception as e:
        log_line(f"script load fail {pid}: {e}")
        return False


def _claim_pid(pid: int) -> object | None:
    """互斥：同一 PID 只允许一个 hook 会话（IFEO 与 watch 不重复注入）。"""
    try:
        import ctypes
        from ctypes import wintypes

        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.CreateMutexW.argtypes = [wintypes.LPVOID, wintypes.BOOL, wintypes.LPCWSTR]
        kernel32.CreateMutexW.restype = wintypes.HANDLE
        kernel32.SetLastError(0)
        handle = kernel32.CreateMutexW(None, False, f"Local\\HillsLiteHookPid-{pid}")
        if not handle:
            return None
        if ctypes.get_last_error() == 183:  # ERROR_ALREADY_EXISTS
            kernel32.CloseHandle(handle)
            return None
        return handle
    except Exception:
        return object()


def _release_claim(handle) -> None:
    if handle is None or type(handle) is object:
        return
    try:
        import ctypes

        ctypes.WinDLL("kernel32").CloseHandle(handle)
    except Exception:
        pass


def attach_pid(device, pid: int) -> str:
    """Single Frida attach. Returns: ok | skip | crash | error."""
    claim = _claim_pid(pid)
    if claim is None:
        log_line(f"skip {pid}: already hooked by another session")
        return "skip"

    try:
        seed_prefs()
        # 极短稳定等待：Store 应用首轮 getAddonLicenses 很早，晚了就只能靠 prefs
        if not _wait_process_stable(pid, settle_s=0.2):
            log_line(f"skip {pid}: process unstable/exited before attach")
            return "skip"

        log_line(f"attach {pid}")
        try:
            session = device.attach(pid)
        except Exception as e:
            log_line(f"attach fail {pid}: {e}")
            return "error"

        detached = {"v": False, "reason": ""}

        def on_detached(reason, *a):
            detached["v"] = True
            detached["reason"] = str(reason)
            log_line(f"detached {pid}: {reason}")

        session.on("detached", on_detached)
        time.sleep(0.05)
        if detached["v"] or not _process_still_alive(pid):
            log_line(f"skip hooks {pid}: died right after attach")
            try:
                session.detach()
            except Exception:
                pass
            return "crash"

        if not _load_hooks(session, pid, detached):
            try:
                session.detach()
            except Exception:
                pass
            return "error"

        return _hold_session(session, pid, detached)
    finally:
        _release_claim(claim)


def kill_hills() -> None:
    device = frida.get_local_device()
    for p in device.enumerate_processes():
        if p.name == "HillsLite.exe":
            try:
                device.kill(p.pid)
                log_line(f"killed HillsLite {p.pid}")
            except Exception as e:
                log_line(f"kill {p.pid}: {e}")
    time.sleep(0.8)


def _ifeo_debugger_cmd() -> str:
    # 用 VBS 包一层：无黑框，且能稳定拉起 python+frida
    vbs = HERE / "ifeo_wrap.vbs"
    script = HERE / "unlock_auto.py"
    # IFEO 会把原始 exe 路径追加到命令行；VBS 无法方便接收，改用直接 python 隐藏启动
    # python.exe -u unlock_auto.py --ifeo  <exe>
    return f'"{PYTHON}" -u "{script}" --ifeo'

def _ifeo_set_debugger(enabled: bool) -> tuple[bool, str]:
    """Register/remove Image File Execution Options debugger. Returns (ok, detail)."""
    import winreg

    last_err = ""
    any_ok = False
    for sub, use_hkcu in IFEO_REG_PATHS:
        root = winreg.HKEY_CURRENT_USER if use_hkcu else winreg.HKEY_LOCAL_MACHINE
        label = "HKCU" if use_hkcu else "HKLM"
        try:
            if enabled:
                key = winreg.CreateKeyEx(root, f"{sub}\\{IFEO_EXE_NAME}", 0, winreg.KEY_SET_VALUE)
                winreg.SetValueEx(key, "Debugger", 0, winreg.REG_SZ, _ifeo_debugger_cmd())
                winreg.CloseKey(key)
                any_ok = True
                last_err = f"{label}: ok"
                log_line(f"IFEO set {label}\\...\\{IFEO_EXE_NAME}")
                # HKCU 成功就够用，不必写 HKLM
                if use_hkcu:
                    break
            else:
                try:
                    key = winreg.OpenKey(root, f"{sub}\\{IFEO_EXE_NAME}", 0, winreg.KEY_SET_VALUE)
                except FileNotFoundError:
                    continue
                try:
                    winreg.DeleteValue(key, "Debugger")
                    log_line(f"IFEO cleared {label}")
                    any_ok = True
                except FileNotFoundError:
                    pass
                winreg.CloseKey(key)
        except PermissionError as e:
            last_err = f"{label}: permission denied ({e})"
            log_line(last_err)
        except Exception as e:
            last_err = f"{label}: {e}"
            log_line(last_err)
    return any_ok, last_err


def _ifeo_temporarily_disabled():
    """Context-manager style: disable IFEO so frida.spawn won't recurse into --ifeo."""
    import winreg

    saved: list[tuple] = []
    for sub, use_hkcu in IFEO_REG_PATHS:
        root = winreg.HKEY_CURRENT_USER if use_hkcu else winreg.HKEY_LOCAL_MACHINE
        path = f"{sub}\\{IFEO_EXE_NAME}"
        try:
            key = winreg.OpenKey(root, path, 0, winreg.KEY_READ | winreg.KEY_SET_VALUE)
            try:
                val, typ = winreg.QueryValueEx(key, "Debugger")
            except FileNotFoundError:
                winreg.CloseKey(key)
                continue
            winreg.DeleteValue(key, "Debugger")
            saved.append((root, path, val, typ))
            winreg.CloseKey(key)
        except Exception:
            continue
    return saved


def _ifeo_restore(saved: list) -> None:
    import winreg

    for root, path, val, typ in saved:
        try:
            key = winreg.CreateKeyEx(root, path, 0, winreg.KEY_SET_VALUE)
            winreg.SetValueEx(key, "Debugger", 0, typ, val)
            winreg.CloseKey(key)
        except Exception as e:
            log_line(f"IFEO restore fail: {e}")


def spawn_and_hook(exe: str | None = None) -> str:
    """Spawn Hills suspended, inject, resume. Used by --launch and --ifeo."""
    seed_prefs()
    target = exe or EXE
    device = frida.get_local_device()
    saved = _ifeo_temporarily_disabled()
    try:
        log_line(f"spawn with hooks: {target}")
        try:
            pid = device.spawn([target])
        except Exception as e:
            log_line(f"spawn failed: {e}")
            return "error"
    finally:
        # restore ASAP so next user click still goes through IFEO
        _ifeo_restore(saved)

    claim = _claim_pid(pid)
    if claim is None:
        log_line(f"spawn pid {pid} already claimed")
        try:
            device.resume(pid)
        except Exception:
            pass
        return "skip"

    try:
        session = device.attach(pid)
        detached = {"v": False, "reason": ""}

        def on_detached(reason, *a):
            detached["v"] = True
            detached["reason"] = str(reason)
            log_line(f"detached {pid}: {reason}")

        session.on("detached", on_detached)
        if not _load_hooks(session, pid, detached):
            try:
                device.resume(pid)
            except Exception:
                pass
            log_line("hooks failed after spawn")
            return "error"

        device.resume(pid)
        log_line(f"resumed {pid}")
        return _hold_session(session, pid, detached)
    finally:
        _release_claim(claim)


def launch_with_unlock() -> None:
    """主动启动（可选）：清旧进程后 spawn 解锁。"""
    kill_hills()
    spawn_and_hook(EXE)


def _hide_console() -> None:
    try:
        import ctypes

        hwnd = ctypes.windll.kernel32.GetConsoleWindow()
        if hwnd:
            ctypes.windll.user32.ShowWindow(hwnd, 0)  # SW_HIDE
    except Exception:
        pass


def ifeo_handler(argv_rest: list[str]) -> None:
    """
    IFEO Debugger 入口：用户点击 Hills Lite 时，系统把我们当调试器拉起。
    命令行类似: python -u unlock_auto.py --ifeo "C:\\...\\HillsLite.exe" ...
    """
    _hide_console()
    seed_prefs()
    exe = EXE
    for a in argv_rest:
        if a and a.lower().endswith("hillslite.exe"):
            exe = a.strip('"')
            break
        if a and "HillsLite" in a and a.lower().endswith(".exe"):
            exe = a.strip('"')
            break
    log_line(f"IFEO intercept → {exe}")
    device = frida.get_local_device()
    existing = find_hills_pids(device)
    if existing:
        log_line(f"IFEO: attach existing {existing[0]}")
        attach_pid(device, existing[0])
        return
    spawn_and_hook(exe)


def _acquire_single_instance() -> object | None:
    """Windows named mutex: only one --watch process."""
    try:
        import ctypes
        from ctypes import wintypes

        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.CreateMutexW.argtypes = [wintypes.LPVOID, wintypes.BOOL, wintypes.LPCWSTR]
        kernel32.CreateMutexW.restype = wintypes.HANDLE
        # Clear last error before CreateMutex so ALREADY_EXISTS is reliable
        kernel32.SetLastError(0)
        name = "Local\\HillsLiteProUnlockWatchdog"
        handle = kernel32.CreateMutexW(None, False, name)
        if not handle:
            return None
        ERROR_ALREADY_EXISTS = 183
        if ctypes.get_last_error() == ERROR_ALREADY_EXISTS:
            kernel32.CloseHandle(handle)
            return None
        return handle
    except Exception:
        return object()  # non-Windows / best-effort: allow run


def watch_loop_threaded() -> None:
    """One watcher; each Hills instance gets a single hook thread (no double-attach)."""
    import atexit
    import threading

    mutex = _acquire_single_instance()
    if mutex is None:
        log_line("another unlock_auto --watch already running; exit")
        return

    def _release_mutex() -> None:
        if mutex is None or type(mutex) is object:
            return
        try:
            import ctypes

            ctypes.WinDLL("kernel32").CloseHandle(mutex)
        except Exception:
            pass

    atexit.register(_release_mutex)

    _hide_console()
    log_line("auto-unlock watchdog running (seamless: click Hills Lite = auto Pro)")
    seed_prefs()
    last_seed = time.time()
    device = frida.get_local_device()
    active: dict[int, threading.Thread] = {}
    cooldown_until: dict[int, float] = {}
    lock = threading.Lock()
    global_cooldown_until = 0.0

    def worker(pid: int) -> None:
        nonlocal global_cooldown_until
        result = "error"
        try:
            result = attach_pid(device, pid)
        except Exception as e:
            log_line(f"worker {pid}: {e}")
            result = "error"
        finally:
            with lock:
                active.pop(pid, None)
                if result in ("crash", "error"):
                    cooldown_until[pid] = time.time() + 15
                    global_cooldown_until = time.time() + 8
                    log_line(f"cooldown after {result} on {pid}")
                elif result == "skip":
                    cooldown_until[pid] = time.time() + 3

    while True:
        try:
            now = time.time()
            if now - last_seed > 120:
                try:
                    seed_prefs()
                except Exception as e:
                    log_line(f"seed err {e}")
                last_seed = now
            try:
                pids = set(find_hills_pids(device))
            except Exception as e:
                log_line(f"enum err {e}")
                try:
                    device = frida.get_local_device()
                except Exception:
                    pass
                time.sleep(1)
                continue
            with lock:
                for p in list(cooldown_until):
                    if p not in pids:
                        cooldown_until.pop(p, None)
                for p in [p for p in active if p not in pids]:
                    active.pop(p, None)

                if now >= global_cooldown_until:
                    for pid in pids:
                        if pid in active:
                            continue
                        if now < cooldown_until.get(pid, 0):
                            continue
                        t = threading.Thread(target=worker, args=(pid,), daemon=True, name=f"hook-{pid}")
                        active[pid] = t
                        t.start()
                        log_line(f"watch hook thread for {pid}")
            time.sleep(0.15)
        except KeyboardInterrupt:
            log_line("stop")
            return
        except Exception as e:
            log_line(f"loop err {e}")
            time.sleep(2)


def _desktop_dir() -> Path:
    """Resolve real Desktop (OneDrive-redirected or classic)."""
    candidates: list[Path] = []
    try:
        import ctypes
        from ctypes import wintypes

        CSIDL_DESKTOP = 0x00
        SHGFP_TYPE_CURRENT = 0
        buf = ctypes.create_unicode_buffer(wintypes.MAX_PATH)
        if ctypes.windll.shell32.SHGetFolderPathW(None, CSIDL_DESKTOP, None, SHGFP_TYPE_CURRENT, buf) == 0:
            candidates.append(Path(buf.value))
    except Exception:
        pass
    for env in ("OneDrive", "OneDriveConsumer", "OneDriveCommercial"):
        root = os.environ.get(env)
        if root:
            candidates.append(Path(root) / "Desktop")
    candidates.append(Path(os.environ["USERPROFILE"]) / "Desktop")
    for p in candidates:
        if p.is_dir():
            return p
    return candidates[-1]


def _start_watchdog_background() -> None:
    """Start unlock_auto --watch fully detached (survives parent exit)."""
    script = HERE / "unlock_auto.py"
    flags = 0
    # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP | CREATE_NO_WINDOW
    if hasattr(subprocess, "DETACHED_PROCESS"):
        flags |= subprocess.DETACHED_PROCESS  # 0x00000008
    if hasattr(subprocess, "CREATE_NEW_PROCESS_GROUP"):
        flags |= subprocess.CREATE_NEW_PROCESS_GROUP  # 0x00000200
    if hasattr(subprocess, "CREATE_NO_WINDOW"):
        flags |= subprocess.CREATE_NO_WINDOW  # 0x08000000
    logf = open(LOG_FILE, "a", encoding="utf-8")
    subprocess.Popen(
        [PYTHON, "-u", str(script), "--watch"],
        cwd=str(HERE),
        creationflags=flags,
        close_fds=True,
        stdin=subprocess.DEVNULL,
        stdout=logf,
        stderr=logf,
    )


def _watchdog_already_running() -> bool:
    try:
        import ctypes
        from ctypes import wintypes

        # 与 watch 内同一 mutex：若已存在则说明有实例
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.CreateMutexW.argtypes = [wintypes.LPVOID, wintypes.BOOL, wintypes.LPCWSTR]
        kernel32.CreateMutexW.restype = wintypes.HANDLE
        kernel32.SetLastError(0)
        h = kernel32.CreateMutexW(None, False, "Local\\HillsLiteProUnlockWatchdog")
        if not h:
            return False
        exists = ctypes.get_last_error() == 183
        kernel32.CloseHandle(h)
        return exists
    except Exception:
        return False


def install_task() -> None:
    script = HERE / "unlock_auto.py"
    # 开机任务：用 cmd start 完全脱离会话，避免被提前杀掉
    # /MIN 最小化；配合 python -u --watch 内部会藏控制台
    tr = f'cmd.exe /c start "HillsUnlock" /MIN "" "{PYTHON}" -u "{script}" --watch'

    # 1) 开机计划任务
    cmd = [
        "schtasks",
        "/Create",
        "/F",
        "/TN",
        TASK_NAME,
        "/SC",
        "ONLOGON",
        "/RL",
        "LIMITED",
        "/TR",
        tr,
    ]
    print("Creating scheduled task:", " ".join(cmd))
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    print((r.stdout or "").strip())
    print((r.stderr or "").strip())
    task_ok = r.returncode == 0

    # 2) Startup：cmd start 拉起，避免 wscript 子进程被回收
    startup = Path(os.environ["APPDATA"]) / r"Microsoft\Windows\Start Menu\Programs\Startup"
    startup.mkdir(parents=True, exist_ok=True)
    vbs = startup / "HillsLiteProUnlock.vbs"
    # 0=hidden window for the cmd host; start launches detached python
    vbs.write_text(
        'Set sh = CreateObject("Wscript.Shell")\r\n'
        f'sh.Run "cmd.exe /c start \"HillsUnlock\" /MIN \"\" \"{PYTHON}\" -u \"{script}\" --watch", 0, False\r\n',
        encoding="utf-8",
    )
    print(f"Startup VBS: {vbs}")

    # 3) IFEO：点击系统里的 Hills Lite 图标 = 自动解锁启动（无感关键）
    ifeo_ok, ifeo_detail = _ifeo_set_debugger(True)
    print(f"IFEO (click-to-unlock): {'OK' if ifeo_ok else 'FAIL'} ({ifeo_detail})")

    # 4) 清理以前的 bat（不再需要）
    try:
        desktop = _desktop_dir()
        for name in ("HillsLite_Pro.bat", "HillsLite_Pro解锁.bat"):
            bat = desktop / name
            if bat.exists():
                bat.unlink()
                print("removed old", bat)
    except Exception:
        pass
    for extra in (HERE / "HillsLite_Pro_launch.vbs", HERE / "_start_watch.vbs"):
        if extra.exists():
            try:
                extra.unlink()
            except Exception:
                pass

    # 5) 写入 Pro 标记 + 启动后台监视
    seed_prefs()
    if _watchdog_already_running():
        print("Watchdog already running; skip start.")
    else:
        _start_watchdog_background()
        print("Watchdog started for current session.")

    print(
        "\n========================================\n"
        "  已开启无感自动解锁\n"
        "========================================\n"
        f"  - 点图标拦截(IFEO): {'已开启' if ifeo_ok else '未开启(仅后台监视)'}\n"
        f"  - 开机后台监视: {vbs}\n"
        f"  - 计划任务: {'成功' if task_ok else '失败(可用 Startup 代替)'}\n"
        f"  - 日志: {LOG_FILE}\n"
        "\n以后怎么用：\n"
        "  直接点「开始菜单 / 任务栏 / 搜索」里的 Hills Lite 即可。\n"
        "  不用 bat，不用手动脚本。\n"
        "\n卸载: python unlock_auto.py --uninstall\n"
    )


def uninstall_task() -> None:
    subprocess.run(["schtasks", "/Delete", "/F", "/TN", TASK_NAME], capture_output=True)
    startup = Path(os.environ["APPDATA"]) / r"Microsoft\Windows\Start Menu\Programs\Startup"
    vbs = startup / "HillsLiteProUnlock.vbs"
    if vbs.exists():
        vbs.unlink()
        print("removed", vbs)
    ok, detail = _ifeo_set_debugger(False)
    print(f"IFEO remove: {ok} ({detail})")
    try:
        desktop = _desktop_dir()
    except Exception:
        desktop = Path(os.environ["USERPROFILE"]) / "Desktop"
    for name in ("HillsLite_Pro.bat", "HillsLite_Pro解锁.bat"):
        bat = desktop / name
        if bat.exists():
            bat.unlink()
            print("removed", bat)
    for tmp in (HERE / "_start_watch.vbs", HERE / "HillsLite_Pro_launch.vbs"):
        if tmp.exists():
            tmp.unlink()
    print(f"removed task {TASK_NAME} (if existed)")
    print("请在任务管理器结束仍在运行的 python/pythonw (命令行含 unlock_auto)")


def main():
    ap = argparse.ArgumentParser(description="Hills Lite seamless Pro unlock")
    ap.add_argument("--watch", action="store_true", help="background watchdog")
    ap.add_argument("--launch", action="store_true", help="manually spawn+unlock (optional)")
    ap.add_argument("--ifeo", action="store_true", help="IFEO debugger entry (do not run manually)")
    ap.add_argument("--seed", action="store_true", help="only write Pro prefs")
    ap.add_argument("--install", action="store_true", help="install seamless auto-unlock")
    ap.add_argument("--uninstall", action="store_true", help="remove auto-unlock")
    args, rest = ap.parse_known_args()

    if args.seed:
        seed_prefs()
        print("prefs seeded")
        return
    if args.install:
        install_task()
        return
    if args.uninstall:
        uninstall_task()
        return
    if args.ifeo:
        ifeo_handler(rest)
        return
    if args.launch:
        launch_with_unlock()
        return
    if args.watch:
        watch_loop_threaded()
        return

    print(__doc__)
    print("安装一次:  python unlock_auto.py --install")
    print("之后直接点 Hills Lite 图标即可。")


if __name__ == "__main__":
    main()
