@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Hills Lite Pro 无感解锁 - 卸载
echo.
echo  将卸载无感解锁（IFEO / 开机启动 / 后台监视）
echo.
pause

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1"
echo.
pause
