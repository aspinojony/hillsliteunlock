#Requires -Version 5.1
# 一键安装：自动准备 Python+frida，配置无感解锁。双击 install.bat 即可。
$ErrorActionPreference = "Stop"
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

$PackageRoot = $PSScriptRoot
$InstallDir  = Join-Path $env:LOCALAPPDATA "HillsLiteProUnlock"
$RuntimeDir  = Join-Path $InstallDir "runtime"
$LogFile     = Join-Path $InstallDir "installer.log"
$PythonVer   = "3.12.8"
$EmbedUrl    = "https://www.python.org/ftp/python/$PythonVer/python-$PythonVer-embed-amd64.zip"
$GetPipUrl   = "https://bootstrap.pypa.io/get-pip.py"

function Write-Log([string]$msg, [string]$color = "White") {
    $line = "[{0}] {1}" -f (Get-Date -Format "HH:mm:ss"), $msg
    Write-Host $line -ForegroundColor $color
    try {
        if (-not (Test-Path $InstallDir)) { New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null }
        Add-Content -Path $LogFile -Value ("[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $msg) -Encoding UTF8
    } catch {}
}

function Download-File([string]$Url, [string]$OutFile) {
    Write-Log "下载: $Url"
    $ProgressPreference = "SilentlyContinue"
    Invoke-WebRequest -Uri $Url -OutFile $OutFile -UseBasicParsing
    if (-not (Test-Path $OutFile)) { throw "下载失败: $Url" }
}

function Test-PythonOk([string]$exe) {
    if (-not $exe -or -not (Test-Path $exe)) { return $false }
    try {
        & $exe -c "import sys; assert sys.version_info[:2] >= (3,10); assert sys.maxsize > 2**32" 2>$null
        return ($LASTEXITCODE -eq 0)
    } catch { return $false }
}

function Find-SystemPython {
    $list = @()
    if ($env:HILLS_UNLOCK_PYTHON) { $list += $env:HILLS_UNLOCK_PYTHON }
    $list += @(
        "$env:LOCALAPPDATA\Programs\Python\Python313\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python311\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python310\python.exe",
        "$env:ProgramFiles\Python313\python.exe",
        "$env:ProgramFiles\Python312\python.exe"
    )
    if (Get-Command py -EA SilentlyContinue) {
        try { $list += (& py -3 -c "import sys; print(sys.executable)" 2>$null).Trim() } catch {}
    }
    if (Get-Command python -EA SilentlyContinue) {
        try { $list += (& python -c "import sys; print(sys.executable)" 2>$null).Trim() } catch {}
    }
    foreach ($c in $list) {
        if (Test-PythonOk $c) { return $c }
    }
    return $null
}

function Ensure-PortablePython {
    $py = Join-Path $RuntimeDir "python.exe"
    if (Test-PythonOk $py) {
        # frida 是否已装
        & $py -c "import frida" 2>$null
        if ($LASTEXITCODE -eq 0) { return $py }
    }

    Write-Log "正在准备内置 Python 运行时（首次需要联网，约 1~3 分钟）..." "Cyan"
    New-Item -ItemType Directory -Path $RuntimeDir -Force | Out-Null
    $zip = Join-Path $InstallDir "python-embed.zip"
    if (-not (Test-Path $zip)) {
        Download-File $EmbedUrl $zip
    }
    if (-not (Test-Path $py)) {
        Write-Log "解压 Python embed..."
        Expand-Archive -Path $zip -DestinationPath $RuntimeDir -Force
    }
    if (-not (Test-Path $py)) { throw "内置 Python 解压失败" }

    # 允许 import site / pip
    $pth = Get-ChildItem $RuntimeDir -Filter "python*._pth" | Select-Object -First 1
    if ($pth) {
        $content = Get-Content $pth.FullName -Raw
        $content = $content -replace '(?m)^#\s*import site\s*$', 'import site'
        if ($content -notmatch '(?m)^import site\s*$') { $content = $content.TrimEnd() + "`r`nimport site`r`n" }
        if ($content -notmatch '(?m)^Lib\\site-packages\s*$') { $content = $content.TrimEnd() + "`r`nLib\\site-packages`r`n" }
        Set-Content -Path $pth.FullName -Value $content -Encoding ASCII
    }

    # pip
    & $py -c "import pip" 2>$null
    if ($LASTEXITCODE -ne 0) {
        $getPip = Join-Path $InstallDir "get-pip.py"
        if (-not (Test-Path $getPip)) { Download-File $GetPipUrl $getPip }
        Write-Log "安装 pip..."
        & $py $getPip --no-warn-script-location 2>&1 | ForEach-Object { Write-Log "  $_" "DarkGray" }
    }

    Write-Log "安装 frida（核心依赖）..."
    & $py -m pip install --upgrade pip --no-warn-script-location 2>&1 | Out-Null
    & $py -m pip install "frida>=16,<18" --no-warn-script-location 2>&1 | ForEach-Object { Write-Log "  $_" "DarkGray" }
    if ($LASTEXITCODE -ne 0) { throw "frida 安装失败，请检查网络后重试" }

    & $py -c "import frida; print(frida.__version__)" 2>&1 | ForEach-Object { Write-Log "frida OK: $_" "Green" }
    return $py
}

function Ensure-Frida([string]$python) {
    & $python -c "import frida" 2>$null
    if ($LASTEXITCODE -eq 0) {
        & $python -c "import frida; print(frida.__version__)" 2>&1 | ForEach-Object { Write-Log "frida: $_" }
        return
    }
    Write-Log "为当前 Python 安装 frida..."
    & $python -m pip install --upgrade pip 2>&1 | Out-Null
    & $python -m pip install "frida>=16,<18" 2>&1 | ForEach-Object { Write-Log "  $_" "DarkGray" }
    if ($LASTEXITCODE -ne 0) { throw "frida 安装失败" }
}

# ================= main =================
Write-Host ""
Write-Host " ========================================" -ForegroundColor Green
Write-Host "  Hills Lite Pro  一键解锁安装" -ForegroundColor Green
Write-Host " ========================================" -ForegroundColor Green
Write-Host ""
Write-Log "安装目录: $InstallDir"

# 0) 必须已装 Hills Lite 本体
$appx = Get-AppxPackage -Name "Mountains.HillsLite" -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $appx) {
    Write-Host ""
    Write-Host "[错误] 本机未安装 Hills Lite（微软商店应用）" -ForegroundColor Red
    Write-Host "请先在 Microsoft Store 搜索安装 Hills Lite，再重新运行本安装程序。" -ForegroundColor Yellow
    exit 2
}
Write-Log ("检测到 Hills Lite v{0}" -f $appx.Version) "Green"

# 1) 准备目录与文件
New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
foreach ($f in @("unlock_auto.py", "requirements.txt")) {
    $src = Join-Path $PackageRoot $f
    if (-not (Test-Path $src)) { throw "安装包损坏，缺少 $f" }
    Copy-Item $src (Join-Path $InstallDir $f) -Force
}
foreach ($f in @("README.txt", "uninstall.bat", "uninstall.ps1", "status.bat", "status.ps1", "install.bat", "install.ps1")) {
    $src = Join-Path $PackageRoot $f
    if (Test-Path $src) { Copy-Item $src (Join-Path $InstallDir $f) -Force }
}

# 2) Python：系统有则用系统，否则自动下内置
$python = Find-SystemPython
if ($python) {
    Write-Log "使用系统 Python: $python" "Green"
    Ensure-Frida $python
} else {
    Write-Log "未检测到系统 Python，将自动安装便携运行时" "Yellow"
    $python = Ensure-PortablePython
    Write-Log "便携 Python: $python" "Green"
}
Set-Content -Path (Join-Path $InstallDir "python.path") -Value $python -Encoding UTF8

# 3) 停掉旧进程
Get-CimInstance Win32_Process -EA SilentlyContinue |
    Where-Object { $_.CommandLine -and $_.CommandLine -match 'unlock_auto\.py' } |
    ForEach-Object {
        Write-Log "停止旧进程 $($_.ProcessId)"
        Stop-Process -Id $_.ProcessId -Force -EA SilentlyContinue
    }
Start-Sleep -Seconds 1

# 4) 写入开机启动 / IFEO / 本地 Pro / 后台监视
$script = Join-Path $InstallDir "unlock_auto.py"
Write-Log "配置无感解锁..."
& $python -u $script --install 2>&1 | ForEach-Object { Write-Log "$_" }
if ($LASTEXITCODE -ne 0) {
    Write-Log "unlock_auto --install 返回码 $LASTEXITCODE" "Yellow"
}

# 5) 结果
Start-Sleep -Seconds 2
$watch = Get-CimInstance Win32_Process -EA SilentlyContinue |
    Where-Object { $_.CommandLine -and $_.CommandLine -match 'unlock_auto\.py' -and $_.CommandLine -match '--watch' }
$startup = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Startup\HillsLiteProUnlock.vbs"
$ifeoOk = $false
try {
    $d = (Get-ItemProperty "HKCU:\Software\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\HillsLite.exe" -Name Debugger -EA Stop).Debugger
    $ifeoOk = [bool]$d
} catch {}

Write-Host ""
Write-Host " ============ 安装完成 ============ " -ForegroundColor Green
Write-Host ("  安装目录 : {0}" -f $InstallDir)
Write-Host ("  后台监视 : {0}" -f ($(if ($watch) { "已运行" } else { "稍后开机自启" })))
Write-Host ("  开机启动 : {0}" -f ($(if (Test-Path $startup) { "已写入" } else { "失败" })))
Write-Host ("  点图标拦截: {0}" -f ($(if ($ifeoOk) { "已开启" } else { "未开(监视仍可用)" })))
Write-Host ""
Write-Host "  现在直接打开「Hills Lite」即可，无需其它操作。" -ForegroundColor Cyan
Write-Host "  卸载请运行 uninstall.bat" -ForegroundColor DarkGray
Write-Host " ================================== " -ForegroundColor Green
Write-Host ""
Write-Log "==== done ===="
exit 0
